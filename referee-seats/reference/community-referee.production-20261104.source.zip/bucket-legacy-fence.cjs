'use strict';
function assertLegacyScoringWritable(room) {
  if (room && Object.prototype.hasOwnProperty.call(room, 'scoreStorage')) {
    throw Error('bucket-scoring-required');
  }
}
module.exports = {assertLegacyScoringWritable};
